document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');

    console.log("Product ID from URL:", productId);

    const products = {
        1: {
            title: 'Double Eagle Noveske NSR 9',
            description: 'Double Eagle EMG NOVESKE NSR 9 M-LOK Devgru N4 MWS GBB Rifle (Dark Earth, Gen 2 Version)',
            price: 'US$352.56',
            image: 'images/noveskensr9.jpeg'
        },
        2: {
            title: 'Cybergun SCAR-H',
            description: 'Cybergun (VFC) SCAR-H CQC GBB Battle Rifle (Tan)',
            price: 'US$384.62',
            image: 'images/scarh.png'
        }
    };

    if (productId && products[productId]) {
        document.getElementById('product-title').textContent = products[productId].title;
        document.getElementById('product-description').textContent = products[productId].description;
        document.getElementById('product-price').textContent = products[productId].price;
        document.getElementById('product-image').src = products[productId].image;
    } else {
        console.log("Product not found or missing product ID.");
        document.querySelector('main').innerHTML = '<p>Товар не найден</p>';
    }

    document.getElementById('add-to-cart').addEventListener('click', () => {
        alert('Товар добавлен в корзину!');
    });
});